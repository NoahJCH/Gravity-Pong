import pygame
from random import randint
from directkeys import ReleaseKey, PressKey, W, S


class Paddle_Bot():

    def moveUp(self):
        ReleaseKey(S)
        PressKey(W)

    def moveDown(self):
        ReleaseKey(W)
        PressKey(S)

    def calcBallPos(self, gravity, velX, velY, posX, posY):
        data = open("ai_data.txt", "w+")
        if (randint(1,10) >5):
            return 0
        else:
            return 600

    def decideMovement(self, predicted_pos, current_pos):
        if (predicted_pos > current_pos):
            moveUp()
        else:
            moveDown()
