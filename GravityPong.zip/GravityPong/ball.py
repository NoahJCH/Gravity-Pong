import pygame
from random import randint
BLACK = (0, 0, 0)
gravity_init = 0.1


class Ball(pygame.sprite.Sprite):

    def __init__(self, color, width, height):

        super().__init__()

        self.image = pygame.Surface([width, height])
        self.image.fill(BLACK)
        self.image.set_colorkey(BLACK)

        pygame.draw.rect(self.image, color, [0, 0, width, height])
        self.velocity = [12*randint(1,2) - 18, 4]
        self.gravity = gravity_init

        self.rect = self.image.get_rect()

    def update(self):
        self.rect.x += self.velocity[0]
        self.rect.y += self.velocity[1]

    def bounce(self):
        self.velocity[0] *= -1

    def gravityEffect(self):
        self.velocity[1] += self.gravity

    def increaseGravity(self, amount):
        self.gravity += amount

    def reset(self, width, height):
        self.rect.x =  width/2
        self.rect.y = height/2
        self.velocity = [12 * randint(1, 2) - 18, 2 + randint(1,100)/25]
        self.gravity = gravity_init
