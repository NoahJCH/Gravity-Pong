import pygame
BLACK = (0, 0, 0)

class Paddle(pygame.sprite.Sprite):

    def __init__(self, color, width, height):
        # calls the parent class (Sprite) constructor
        super().__init__()

        self.image = pygame.Surface([width, height])
        self.image.fill(BLACK)
        self.image.set_colorkey(BLACK)

        pygame.draw.rect(self.image, color, [0, 0, width, height])
        self.rect = self.image.get_rect()

    def moveUp(self,pixels, min):
        self.rect.y -= pixels
        if self.rect.y < min:
            self.rect.y = min

    def moveDown(self,pixels, max):
        self.rect.y += pixels
        if self.rect.y > max - self.rect.height:
            self.rect.y = max - self.rect.height

    def paddleReset(self, screen_height):
        self.rect.y = screen_height/2

