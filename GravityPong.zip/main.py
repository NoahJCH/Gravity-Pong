import pygame
from random import randint
from paddle import Paddle
from ball import Ball
from paddle_bot import Paddle_Bot
pygame.init()

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

screen_width = 800
screen_height = 600
size = (screen_width, screen_height)
screen = pygame.display.set_mode(size)
pygame.display.set_caption("Gravity Pong")

clock = pygame.time.Clock()

running = True

paddle_width = 10
paddle_height = 100

paddleA = Paddle(WHITE, paddle_width, paddle_height)
paddleA.rect.x = 20
paddleA.rect.y = screen_height / 2

paddleB = Paddle(WHITE, paddle_width, paddle_height)
paddleB.rect.x = screen_width - ( paddle_width + 20)
paddleB.rect.y = screen_height / 2

player_speed = 8
gravity_value = 0.03

ball_width = 10
ball_height = 10
ball = Ball(WHITE, ball_width, ball_height)
ball.rect.x = screen_width/2
ball.rect.y = screen_height/2

sprites_list = pygame.sprite.Group()
sprites_list.add(paddleA)
sprites_list.add(paddleB)
sprites_list.add(ball)

scoreA = 0
scoreB = 0

paddleAI = Paddle_Bot()

def pause():
    kill = False
    while True:
        event = pygame.event.wait()
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            break  # Exit infinite loop
        if event.type == pygame.QUIT:
            kill = True
            break
    if kill:
        return True
    else:
        return False


# Main Program Loop
while running:
    # Event loop
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
   # player input
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w] and not keys[pygame.K_s]:
        paddleA.moveUp(player_speed, 0)
    elif keys[pygame.K_s] and not keys[pygame.K_w]:
        paddleA.moveDown(player_speed, screen_height)
    if keys[pygame.K_UP] and not keys[pygame.K_DOWN]:
        paddleB.moveUp(player_speed, 0)
    elif keys[pygame.K_DOWN] and not keys[pygame.K_UP]:
        paddleB.moveDown(player_speed, screen_height)

        # Game Logic


    sprites_list.update()

    # gravity effect
    ball.gravityEffect()

    # ball collision testing
    if ball.rect.x > screen_width - ball_width:
        scoreA += 1
        ball.reset(screen_width, screen_height)
        if scoreA >= 5:
            running = False
        else:
            if pause():
                running = False
    if ball.rect.x < 0:
        scoreB +=1
        ball.reset(screen_width, screen_height)
        paddleA.paddleReset(screen_height)
        paddleB.paddleReset(screen_height)
        if scoreB >= 5:
            running = False
        else:
            if pause():
                running = False
    if ball.rect.y > screen_height - ball_height: # add randomness
        ball.velocity[1] = ball.velocity[1] * -1
        ball.rect.y -= 2
    if ball.rect.y < 0:
        ball.velocity[1] *= -1
        ball.rect.y += 2

    # paddle collision detection
    if (pygame.sprite.collide_mask(ball, paddleA) and ball.rect.x >= paddleA.rect.x + paddle_width/2) or (pygame.sprite.collide_mask(ball, paddleB) and ball.rect.x <= paddleB.rect.x) :
        ball.bounce()
        ball.increaseGravity(gravity_value)

    # Drawing Code
    screen.fill(BLACK)
    pygame.draw.line(screen, WHITE, [screen_width/2, 0], [screen_width/2, screen_height], 5)
    sprites_list.draw(screen)

    scoreFont = pygame.font.Font(None, 74)
    text = scoreFont.render(str(scoreA), 1, WHITE)
    screen.blit(text, (screen_width/4 -20, 10))
    text = scoreFont.render(str(scoreB), 1, WHITE)
    screen.blit(text, (3*screen_width/4 -20, 10))

    pygame.display.flip()

    # Framerate limiter
    clock.tick(60)

pygame.quit()